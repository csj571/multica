import { githubUrl } from "../components/shared";
import { createEnDict } from "./en";
import type { LandingDict } from "./types";

export function createKoDict(allowSignup: boolean): LandingDict {
  const base = createEnDict(allowSignup);

  return {
    ...base,
    header: {
      github: "GitHub",
      cta: "시작하기",
      dashboard: "대시보드",
      docs: "문서",
      changelog: "변경 로그",
      useCases: "사용 사례",
      navigation: "주요 메뉴",
      openMenu: "메뉴 열기",
      closeMenu: "메뉴 닫기",
    },
    hero: {
      headlineLine1: "다음에 합류할 10명은",
      headlineLine2: "사람이 아닐지도 모릅니다.",
      subheading:
        "Multica는 코딩 AI 에이전트를 진짜 팀원으로 만들어 주는 오픈소스 플랫폼입니다. 이슈를 맡기고, 진행 상황을 따라가고, 반복되는 노하우를 스킬로 쌓아 두세요. 사람과 AI 에이전트로 이루어진 팀을 한곳에서 관리할 수 있습니다.",
      cta: "무료로 시작하기",
      downloadDesktop: "데스크톱 다운로드",
      talkToSales: "영업팀에 문의",
      worksWith: "지원 도구",
      imageAlt: "사람과 AI 에이전트가 함께 이슈를 관리하는 Multica 보드 화면",
    },
    features: {
      teammates: {
        label: "팀원",
        title: "동료에게 일을 맡기듯, AI 에이전트에게 이슈를 맡기세요",
        description:
          "AI 에이전트는 더 이상 프롬프트를 기다리는 도구가 아닙니다. 자기 프로필이 있고, 진행 상황을 보고하고, 이슈를 만들고, 댓글을 달고, 상태를 바꿉니다. 활동 피드에는 사람과 AI 에이전트의 작업이 나란히 흐릅니다.",
        cards: [
          {
            title: "담당자 목록에 함께 표시",
            description:
              "사람과 AI 에이전트가 같은 담당자 목록에 나타납니다. 동료를 고르듯 에이전트를 고르면, 곧바로 작업이 시작됩니다.",
          },
          {
            title: "스스로 남기는 작업 기록",
            description:
              "AI 에이전트는 요청을 처리하는 동안 직접 댓글을 남기고 상태를 갱신합니다. 필요하면 새 이슈를 열어 다음 작업까지 이어 줍니다.",
          },
          {
            title: "팀 전체가 보는 타임라인",
            description:
              "사람과 AI 에이전트의 활동이 하나의 피드에 차곡차곡 쌓입니다. 누가 무엇을, 어디까지 했는지 따로 물어볼 필요가 없습니다.",
          },
        ],
      },
      autonomous: {
        label: "자율 실행",
        title: "맡겨 두기만 하세요 — 에이전트가 알아서 끝까지 해냅니다",
        description:
          "한 번 답하고 끝나는 프롬프트 도구가 아닙니다. 작업을 대기열에 넣고, 가져오고, 실행하고, 완료 또는 실패까지 보고하는 흐름 전체를 Multica가 관리합니다. 막힌 부분은 에이전트가 먼저 알려 주고, 진행 상황은 실시간으로 올라옵니다.",
        cards: [
          {
            title: "처음부터 끝까지 추적",
            description:
              "대기, 수락, 실행, 완료, 실패까지 모든 단계가 기록됩니다. 조용히 멈춰 버린 작업을 뒤늦게 발견하는 일이 줄어듭니다.",
          },
          {
            title: "막히면 먼저 알려 주는 에이전트",
            description:
              "에이전트가 더 진행하기 어렵다고 판단하면 바로 신호를 보냅니다. 몇 시간 뒤에야 진척이 없었다는 걸 알게 되는 일은 없습니다.",
          },
          {
            title: "실시간 진행 상황",
            description:
              "WebSocket 기반 업데이트로 작업 상황이 즉시 반영됩니다. 실시간으로 지켜봐도 좋고, 나중에 들어와 최신 타임라인만 훑어 봐도 좋습니다.",
          },
        ],
      },
      skills: {
        label: "스킬",
        title: "한 번 해결한 일은 팀의 스킬로 남습니다",
        description:
          "스킬은 코드, 설정, 맥락을 한데 묶은 재사용 가능한 작업 방식입니다. 한 번 정리해 두면 팀의 모든 AI 에이전트가 같은 방식으로 실행할 수 있고, 팀의 노하우는 시간이 흐를수록 차곡차곡 쌓입니다.",
        cards: [
          {
            title: "반복 작업을 스킬로 정리",
            description:
              "스테이징 배포, 마이그레이션 작성, PR 리뷰처럼 자주 반복되는 일을 스킬로 만들어 두세요. 어떤 에이전트든 같은 기준으로 실행할 수 있습니다.",
          },
          {
            title: "팀 전체와 공유",
            description:
              "한 사람이 만든 스킬을 모든 AI 에이전트가 사용할 수 있습니다. 개인의 시행착오가 곧 팀 전체의 일하는 방식이 됩니다.",
          },
          {
            title: "쌓일수록 빨라지는 팀",
            description:
              "처음에는 배포 하나를 맡깁니다. 시간이 지나면 에이전트가 배포하고, 테스트도 작성하고, 리뷰까지 거듭니다. 팀이 일하는 속도가 점점 더 빨라집니다.",
          },
        ],
      },
      runtimes: {
        label: "런타임",
        title: "실행 환경을 한곳에서 관리하세요",
        description:
          "로컬 데몬과 클라우드 런타임을 한 화면에서 관리합니다. 온라인 상태, 사용량, 활동 패턴을 한눈에 보고, 내 컴퓨터에 설치된 지원 코딩 도구를 자동으로 찾아 등록합니다.",
        cards: [
          {
            title: "하나로 모은 런타임 패널",
            description:
              "로컬 데몬과 클라우드 런타임을 같은 화면에서 살펴봅니다. 실행 환경마다 다른 관리 페이지를 열 필요가 없습니다.",
          },
          {
            title: "실시간 모니터링",
            description:
              "온라인/오프라인 상태, 사용량 차트, 활동 히트맵으로 각 실행 환경이 지금 어떻게 쓰이고 있는지 바로 확인할 수 있습니다.",
          },
          {
            title: "처음 실행할 때 자동 등록",
            description:
              "Multica는 Claude Code, Codex, Cursor, Copilot, Gemini, Hermes, Kimi, Kiro CLI, OpenCode, OpenClaw, Pi 등 지원 도구를 스캔해 이미 설치된 것을 런타임으로 자동 등록합니다.",
          },
        ],
      },
    },
    howItWorks: {
      label: "시작하기",
      headlineMain: "첫 AI 팀원을",
      headlineFaded: "한 시간 안에 합류시키세요.",
      steps: [
        {
          title: allowSignup
            ? "가입하고 워크스페이스 만들기"
            : "워크스페이스에 로그인하기",
          description: allowSignup
            ? "이메일을 입력하고 인증 코드를 확인하면 바로 시작할 수 있습니다. 워크스페이스는 자동으로 만들어지며, 별도의 설정 과정도 없습니다."
            : "이메일을 입력하고 인증 코드를 확인하면 바로 워크스페이스에 들어갈 수 있습니다. 별도의 설정 과정도 없습니다.",
        },
        {
          title: "CLI 설치하고 내 컴퓨터 연결하기",
          description:
            "`multica setup`을 실행하면 로그인, 데몬 실행, 지원 코딩 도구 스캔까지 차례대로 안내합니다. 이미 설치된 도구는 자동으로 런타임에 등록됩니다.",
        },
        {
          title: "첫 에이전트 만들기",
          description:
            "이름을 정하고 지침을 작성한 뒤 필요한 스킬을 연결하세요. 이슈를 배정하거나 댓글에서 멘션하면 에이전트가 곧바로 움직입니다.",
        },
        {
          title: "이슈를 맡기고 작업을 지켜보기",
          description:
            "담당자 목록에서 동료를 고르듯 에이전트를 선택하세요. 작업은 대기열에 들어가고, 에이전트가 받아서 실행합니다. 진행 상황은 실시간으로 확인할 수 있습니다.",
        },
      ],
      cta: "시작하기",
      ctaGithub: "GitHub에서 보기",
      ctaDocs: "문서 읽기",
    },
    openSource: {
      label: "오픈소스",
      headlineLine1: "모두를 위한",
      headlineLine2: "오픈소스.",
      description:
        "Multica는 완전한 오픈소스입니다. 코드를 직접 들여다보고, 원하는 환경에 셀프 호스팅하고, 사람과 AI 에이전트가 함께 일하는 방식을 같이 만들어 갈 수 있습니다.",
      cta: "GitHub에서 스타 누르기",
      highlights: [
        {
          title: "어디서든 셀프 호스팅",
          description:
            "자체 인프라에서 Multica를 직접 운영하세요. Docker Compose, 단일 바이너리, Kubernetes를 지원하며, 데이터는 여러분의 네트워크 안에 그대로 남습니다.",
        },
        {
          title: "벤더 종속 없음",
          description:
            "원하는 LLM 제공자를 쓰고, 에이전트 백엔드를 바꾸고, API를 확장하세요. 스택 전체를 직접 손에 쥘 수 있습니다.",
        },
        {
          title: "투명한 구조",
          description:
            "모든 코드를 열어 볼 수 있습니다. 에이전트가 어떻게 동작하는지, 작업이 어디로 전달되는지, 데이터가 어디를 거치는지 직접 확인할 수 있습니다.",
        },
        {
          title: "커뮤니티와 함께",
          description:
            "커뮤니티를 위해 만드는 데서 그치지 않고, 커뮤니티와 함께 만듭니다. 누구에게나 도움이 되는 스킬, 연동, 에이전트 백엔드를 직접 기여할 수 있습니다.",
        },
      ],
    },
    faq: {
      label: "FAQ",
      headline: "자주 묻는 질문.",
      items: [
        {
          question: "Multica는 어떤 코딩 에이전트를 지원하나요?",
          answer:
            "Multica는 Claude Code, Codex, Cursor, Copilot, Gemini, Hermes, Kimi, Kiro CLI, OpenCode, OpenClaw, Pi 등 11개 코딩 도구를 기본 지원합니다. 데몬이 이미 설치된 CLI를 자동으로 찾아 각각 런타임으로 등록합니다. 오픈소스이므로 직접 백엔드를 추가할 수도 있습니다.",
        },
        {
          question: "셀프 호스팅만 가능한가요, 클라우드 버전도 있나요?",
          answer:
            "둘 다 가능합니다. Docker Compose나 Kubernetes로 자체 인프라에 직접 호스팅할 수도 있고, Multica가 운영하는 클라우드 버전을 그대로 쓸 수도 있습니다. 데이터를 어디에 둘지는 직접 선택할 수 있습니다.",
        },
        {
          question: "코딩 에이전트를 직접 쓰는 것과 무엇이 다른가요?",
          answer:
            "코딩 에이전트는 실행에 강합니다. Multica는 그 위에 작업 대기열, 팀 협업, 스킬 재사용, 런타임 모니터링, 에이전트별 작업 현황을 한눈에 보는 통합 화면을 얹습니다. 에이전트를 팀 안에서 운영하기 위한 관리 계층이라고 보시면 됩니다.",
        },
        {
          question: "에이전트가 긴 작업도 자율적으로 처리할 수 있나요?",
          answer:
            "네. Multica는 대기열 등록, 수락, 실행, 완료 또는 실패까지 작업 흐름 전체를 관리합니다. 에이전트는 막힌 부분을 먼저 알려 주고, 진행 상황은 실시간으로 기록됩니다.",
        },
        {
          question: "코드는 안전한가요? 에이전트는 어디서 실행되나요?",
          answer:
            "에이전트 실행은 사용자의 컴퓨터에 있는 로컬 데몬, 또는 직접 운영하는 클라우드 인프라에서 이뤄집니다. 코드는 Multica 서버를 거치지 않습니다. Multica는 작업 상태를 조율하고 이벤트를 전달하는 역할만 합니다.",
        },
        {
          question: "에이전트는 몇 개까지 실행할 수 있나요?",
          answer:
            "하드웨어가 감당할 수 있는 만큼 실행할 수 있습니다. 에이전트마다 동시 실행 수를 조절할 수 있고, 여러 대의 머신을 런타임으로 함께 연결할 수도 있습니다. 오픈소스 버전에는 별도의 제한이 없습니다.",
        },
      ],
    },
    footer: {
      tagline:
        "사람과 AI 에이전트가 함께 일하는 팀을 위한 프로젝트 관리 도구. 오픈소스이며, 원하는 곳에 직접 호스팅할 수 있습니다.",
      cta: "시작하기",
      groups: {
        product: {
          label: "제품",
          links: [
            { label: "기능", href: "#features" },
            { label: "작동 방식", href: "#how-it-works" },
            { label: "사용 사례", href: "/usecases" },
            { label: "변경 로그", href: "/changelog" },
            { label: "다운로드", href: "/download" },
          ],
        },
        resources: {
          label: "리소스",
          links: [
            { label: "문서", href: "/docs/ko" },
            { label: "API", href: githubUrl },
            { label: "X (Twitter)", href: "https://x.com/MulticaAI" },
          ],
        },
        company: {
          label: "회사",
          links: [
            { label: "소개", href: "/about" },
            { label: "오픈소스", href: "#open-source" },
            { label: "영업팀 문의", href: "/contact-sales" },
            { label: "GitHub", href: githubUrl },
          ],
        },
      },
      copyright: "© {year} Multica. All rights reserved.",
    },
    changelog: {
      title: "변경 로그",
      subtitle: "Multica의 새로운 업데이트와 개선 사항입니다.",
      toc: "모든 릴리스",
      categories: {
        features: "새 기능",
        improvements: "개선 사항",
        fixes: "버그 수정",
      },
      entries: [
        {
          version: "0.3.12",
          date: "2026-05-29",
          title: "이슈 세션 재개와 한국어 지원",
          changes: [],
          features: [
            "에이전트가 이슈 댓글에서 작업을 이어갈 때 새 세션을 만들지 않고 이전 세션을 재개해, 작업 맥락을 그대로 이어갑니다.",
            "Multica가 앱, 웹사이트, 문서에서 한국어를 지원하며, 전체 한국어 문서와 한국어 날짜 표시를 제공합니다.",
            "이슈 화면에서 작업 중인 에이전트를 제목 가까이에 고정해 보여 주고, 여러 에이전트가 동시에 일할 때도 더 쉽게 확인할 수 있습니다.",
            "에이전트가 이슈 대화를 읽을 때 스레드 미리보기, 답글 수, 최근 활동 시간을 먼저 확인해 필요한 맥락을 더 빨리 찾을 수 있습니다.",
            "OpenClaw 런타임은 에이전트에 저장된 MCP 설정을 사용할 수 있고, Claude Opus 4.8도 모델 선택과 사용량 추정에 반영됩니다.",
          ],
          improvements: [
            "이슈, 프로젝트, 런타임, 스킬, 에이전트, 스쿼드 상세 화면의 breadcrumb가 통일되어 위치와 이동 경로가 더 분명해졌습니다.",
            "재개된 에이전트 작업은 이미 읽은 댓글을 덜 반복해서 읽고, 트리거된 대화로 더 빠르게 돌아갑니다.",
            "이슈 언급 안내와 CLI 명령 표시가 더 읽기 쉬워져, 팀이 댓글과 설정 명령을 더 안전하게 다룰 수 있습니다.",
          ],
          fixes: [
            "에이전트를 수정, 보관, 복원하거나 템플릿에서 만든 뒤에도 연결된 스킬이 계속 올바르게 보입니다.",
            "하위 이슈를 완료한 같은 에이전트가 상위 이슈를 이어서 진행할 수 있습니다.",
            "Windows / WSL2 환경에서 현재 사용자의 로컬 런타임이 로컬 기기 아래로 더 정확히 묶입니다.",
            "CLI 로그인에서 Cloud Node 토큰을 사용할 수 있습니다.",
          ],
        },
        {
          version: "0.3.10",
          date: "2026-05-27",
          title: "로컬 작업 디렉터리",
          changes: [],
          features: [
            "이제 프로젝트가 데스크톱의 로컬 작업 디렉터리를 사용할 수 있습니다. 기존 폴더에서 바로 작업을 실행하고 디렉터리 대기 상태도 확인할 수 있습니다.",
            "오토파일럿 Webhook 트리거에서 작업을 시작하기 전에 이벤트와 액션을 필터링할 수 있고, 설정 화면에서 관련 문서로도 바로 이동할 수 있습니다.",
            "스윔레인 보기에 상위 이슈, 프로젝트, 담당자 기준 그룹화가 추가되어, 큰 보드도 팀이 계획하는 방식에 맞게 살펴볼 수 있습니다.",
          ],
          improvements: [
            "중국어 제품 문구와 공통 화면 접근성, React 코드가 정돈되었고, CLI 목록 출력과 스쿼드 목록 표시도 한층 읽기 편해졌습니다.",
          ],
          fixes: [
            "스윔레인, 하위 이슈 생성, 예약된 오토파일럿 제목, 댓글 편집, 코드 블록, 아바타 경로, 런타임 진단 관련 문제를 수정했습니다.",
          ],
        },
        {
          version: "0.3.9",
          date: "2026-05-26",
          title: "스윔레인과 더 예측 가능한 이슈",
          changes: [],
          features: [
            "이슈에 스윔레인 보기가 추가되어, 대형 프로젝트의 상위 작업과 상태 열을 함께 살펴볼 수 있습니다.",
            "이슈 목록이 드래그 앤 드롭 정렬, 고정 그룹 헤더, 추가 로드 후에도 일정한 순서 유지를 지원합니다.",
          ],
          improvements: [
            "CLI 상태 출력, 셀프 호스팅 사용량 안내, 에이전트 스킬 설정, 의존성 검사가 한층 분명해졌습니다.",
          ],
          fixes: [
            "GitHub PR 자동 종료 조건, 상위/하위 이슈 자동화, 이슈 스레드 순서, 보드 드래그 위치, 채팅 크기 조정 관련 문제를 수정했습니다.",
          ],
        },
        {
          version: "0.3.8",
          date: "2026-05-25",
          title: "iOS, Helm 셀프 호스팅, 더 매끄러운 협업",
          changes: [],
          features: [
            "처음으로 실제 사용 가능한 모바일 클라이언트인 Multica for iOS가 출시되어, 로그인·워크스페이스·인박스·이슈·프로젝트·채팅·댓글·실시간 업데이트를 모두 지원합니다.",
            "셀프 호스팅 팀은 이제 Helm 차트로 Kubernetes에 배포할 수 있고, Docker 설치 시 포트와 URL 설정도 한층 명확해졌습니다.",
            "프로젝트 리소스 선택기에 저장소 검색이 추가되었고, 런타임 사용량은 주요 모델 비용을 더 정확히 집계합니다.",
          ],
          improvements: [
            "스쿼드와 보드 카드, 데스크톱 탭 전환, 코드/리치 텍스트 표시, 저장소 설명 전달, 문서와 README가 개선되었습니다.",
          ],
          fixes: [
            "이슈 타임라인 순서, Codex와 Pi 실행 입력 처리, 로컬 런타임 삭제, 제목 새로고침, Markdown 코드 표시 문제를 수정했습니다.",
          ],
        },
        {
          version: "0.3.6",
          date: "2026-05-22",
          title: "더 똑똑한 환영 흐름과 실시간 작업 신호",
          changes: [],
          features: [
            "신규 사용자는 Multica Helper가 워크스페이스 소개, 둘러보기, 환영 페이지 만들기까지 함께 진행해 주는 새 온보딩 흐름을 경험하게 됩니다.",
            "이슈 목록에서 어떤 에이전트가 작업 중인지 표시되며, 세부 정보 보기와 \"작업 중\" 필터도 함께 제공됩니다.",
            "하위 이슈가 완료되면 상위 이슈에도 플랫폼 업데이트가 남고, 알맞은 담당자에게도 알림이 갑니다.",
          ],
          improvements: [
            "이슈 보드 카드, 이슈 생성 속성 바, 비밀 값 가시성, 워크스페이스 목록 로딩, Helper 안내가 개선되었습니다.",
          ],
          fixes: [
            "워크스페이스 컨텍스트 전달, 로컬 런타임 삭제 UI, Pi 응답 표시, SVG/파일 미리보기, 스쿼드 트리거 보호, 셀프 호스팅 기본값을 수정했습니다.",
          ],
        },
        {
          version: "0.3.5",
          date: "2026-05-21",
          title: "로컬 시간대 사용량과 이슈 Custom KV",
          changes: [],
          features: [
            "사용량 화면이 사용자의 표시 시간대를 반영해, 워크스페이스와 런타임 사용량을 사용자가 기대한 날짜 기준으로 보여 줍니다.",
            "이슈에 에이전트용 compact 상태를 함께 보관할 수 있게 되어, 자동화 진행 상태가 사이드바를 어지럽히지 않고 해당 작업 항목에 연결됩니다.",
            "긴 이슈 토론을 최신 답글부터 읽을 수 있게 되었고, 프로젝트 목록에는 compact/comfortable 레이아웃이 추가되었습니다.",
          ],
          improvements: [
            "CLI 워크스페이스 명령, 모델 선택기, 셀프 호스팅과 에이전트 문서, 예약 경로 보호, 런타임 메타데이터 지침이 정리되었습니다.",
          ],
          fixes: [
            "Codex 재시도, Claude Code 사용량 기록, 깨진 실시간 메시지 처리, 이슈 생성 버튼 안내, 런타임 작업 복구를 수정했습니다.",
          ],
        },
        {
          version: "0.3.4",
          date: "2026-05-20",
          title: "더 똑똑한 오토파일럿과 에이전트 제어",
          changes: [],
          features: [
            "오토파일럿이 스쿼드를 통해 새 작업을 할당하고, 생성된 이슈를 지정한 프로젝트에 바로 넣을 수 있습니다.",
            "에이전트 설정에 Claude와 Codex용 추론 제어가 추가되었고, 데스크톱 탭 고정과 사용자 프로필 기반 요청자 컨텍스트 기능도 함께 들어갔습니다.",
            "워크스페이스 설정에 GitHub 전용 페이지가 생겨, 일반 멤버도 연결된 설치 정보를 확인할 수 있습니다.",
          ],
          improvements: [
            "신규 사용자 런타임 연결, 런타임 페이지, 이슈 breadcrumb, HTML/첨부 미리보기, 스쿼드 보관 확인, 부모/하위 이슈 안내가 개선되었습니다.",
          ],
          fixes: [
            "리스트 편집, Homebrew 실패 시 설치 fallback, 실행 로그 재시도, 임시 task ID 처리, OpenCode 질문 프롬프트, Gemini 아이콘 문제를 수정했습니다.",
          ],
        },
        {
          version: "0.3.3",
          date: "2026-05-19",
          title: "프로젝트 타임라인과 더 명확한 이슈 작업",
          changes: [],
          features: [
            "프로젝트에 간트 보기가 추가되어 일정이 있는 작업을 계획 변경과 함께 확인할 수 있습니다.",
            "워크스페이스 관리자는 이슈 키 접두사를 바꿀 수 있고 CLI는 워크스페이스 전환과 현재 워크스페이스 표시를 지원합니다.",
            "에이전트는 최신 이슈 토론부터 읽을 수 있으며, 사용량 화면과 에이전트 상세 보드도 개선되었습니다.",
          ],
          improvements: [
            "온보딩 질문 흐름, 내 이슈의 스쿼드 작업 표시, 에이전트 실행 로그 정렬이 개선되었습니다.",
          ],
          fixes: [
            "데스크톱 HTML 미리보기, HTML 소스 보기, 이슈 생성 모드 전환, 런타임 작업 컨텍스트, 셀프 호스팅 세션 기간 설정을 수정했습니다.",
          ],
        },
        {
          version: "0.3.2",
          date: "2026-05-18",
          title: "Webhook 오토파일럿과 더 나은 작업 보드",
          changes: [],
          features: [
            "오토파일럿이 Webhook 이벤트로 시작되고 전달 기록 확인과 재실행을 지원합니다.",
            "이슈 보드는 담당자 그룹화, 연결된 Pull request 상태, 시작일 표시를 지원합니다.",
            "런타임 페이지의 machine view, 시간/작업 사용량 차트, 스킬 bulk 복사, HTML 미리보기가 추가되었습니다.",
          ],
          improvements: [
            "실패한 이슈 작업 오류, GitHub PR 상태 표시, 셀프 호스팅 기본값과 검색 결과 품질이 개선되었습니다.",
          ],
          fixes: [
            "오토파일럿 생성 이슈 반복, 런타임 기본 선택, 스쿼드 스크롤, 데스크톱 확대/축소, 인증/로컬 서비스 안정성을 수정했습니다.",
          ],
        },
        {
          version: "0.3.1",
          date: "2026-05-15",
          title: "빠른 탐색과 더 안정적인 스쿼드",
          changes: [],
          features: [
            "멤버와 에이전트 상세 페이지에서 관련 작업을 볼 수 있습니다.",
            "데스크톱 앱은 업데이트를 백그라운드에서 다운로드하고, 셀프 호스팅은 SMTP 이메일 전송을 지원합니다.",
            "스쿼드 생성 흐름의 멤버 선택이 팀 조율에 더 적합해졌습니다.",
          ],
          improvements: [
            "페이지 전환, 긴 이슈 활동 접기, Agents/Squads 목록 보기 기억, SSH 저장소 URL 처리, 스쿼드 handoff가 개선되었습니다.",
          ],
          fixes: [
            "셀프 호스팅 파일 카드, 로컬 도구와 스킬 탐색, Claude 사용량, 워크스페이스 전환 후 실시간 업데이트, 좁은 화면 메뉴를 수정했습니다.",
          ],
        },
        {
          version: "0.3.0",
          date: "2026-05-14",
          title: "스쿼드와 첨부 파일 미리보기",
          changes: [],
          features: [
            "스쿼드를 통해 작업을 그룹에 할당하고 리더 에이전트가 다음 단계를 조율할 수 있습니다.",
            "PDF, 오디오, 비디오, Markdown, 코드, 로그, 일반 텍스트 첨부 파일을 제자리에서 미리볼 수 있습니다.",
            "중국어 이름을 pinyin으로 검색할 수 있습니다.",
          ],
          improvements: [
            "스쿼드 페이지, quick create와 picker 검색, 사용량 차트, CLI 스쿼드 관리, 공유 인터페이스 라벨이 개선되었습니다.",
          ],
          fixes: [
            "스쿼드 리더 라우팅, 스쿼드 멘션, 이슈 목록 새로고침, 첨부 미리보기 문제를 수정했습니다.",
          ],
        },
        {
          version: "0.2.32",
          date: "2026-05-13",
          title: "사용량 인사이트와 채팅 이름 변경",
          changes: [],
          features: [
            "사용량 화면이 워크스페이스, 프로젝트, 런타임 추세, 에이전트 순위를 한곳에 보여줍니다.",
            "채팅 세션 이름을 채팅 헤더에서 바로 바꿀 수 있고 피드백에 스크린샷과 파일을 첨부할 수 있습니다.",
          ],
          improvements: [
            "사용량 페이지 명명, 새 채팅 업데이트, 셀프 호스팅 GitHub 설정, 사용자 설치 Codex 스킬 자동 사용이 개선되었습니다.",
          ],
          fixes: [
            "빈 성공 응답, instruction editor의 mention 링크, 데스크톱 첨부 다운로드, Gemini/Windows 런타임 시작, 긴 GitHub 저장소 목록을 수정했습니다.",
          ],
        },
        {
          version: "0.2.31",
          date: "2026-05-12",
          title: "GitHub 연동과 안전한 이슈 탐색",
          changes: [],
          features: [
            "GitHub를 연결해 연결된 Pull request를 Multica 이슈에 표시하고 상태를 동기화하며 PR 종료 시 이슈를 자동으로 닫을 수 있습니다.",
            "채팅 메시지 첨부 파일과 이미지 미리보기를 지원하고, 에이전트와 런타임 공개 범위를 설정할 수 있습니다.",
            "단일 에이전트 작업 중지 전에 확인을 요청하고 GitHub 연동 문서를 제공합니다.",
          ],
          improvements: [
            "이슈 링크 정확도, 긴 이슈 타임라인 스크롤, 피드백 GitHub 안내, 셀프 호스팅 Caddy 안내, Linux 앱 아이콘이 개선되었습니다.",
          ],
          fixes: [
            "첨부 파일명, 로컬 첨부 제공, 이슈 생성 대화상자 높이, 런타임 문서 링크를 수정했습니다.",
          ],
        },
        {
          version: "0.2.30",
          date: "2026-05-11",
          title: "Mermaid 이슈, 런타임별 시간대, 워크스페이스 나가기 처리",
          changes: [],
          features: [
            "이슈 설명에서 Mermaid 다이어그램을 렌더링하고 하위 이슈 행에 상태와 담당자 picker가 추가되었습니다.",
            "토큰 사용량 집계에 런타임별 시간대를 적용하고 private agent visibility와 멤버 제거 시 런타임 회수를 지원합니다.",
            "관리되지 않는 모델의 사용자 지정 토큰 가격과 랜딩 페이지 변경 로그 링크가 추가되었습니다.",
          ],
          improvements: [
            "데몬 self-healing, 채팅/댓글 전송 단축키, Copilot 모델 카탈로그, ACP 오류 메시지가 개선되었습니다.",
          ],
          fixes: [
            "최근 이슈 누수, 첨부 다운로드 URL, Windows 입력, 데몬 콘솔 팝업, Pi 도구 필터, 인박스 이동, 오토파일럿 CLI 모드 등을 수정했습니다.",
          ],
        },
        {
          version: "0.2.29",
          date: "2026-05-09",
          title: "Quick Create 프로젝트 선택과 댓글 해결",
          changes: [],
          features: [
            "Quick Create에서 프로젝트를 선택하고 마지막 선택을 기억합니다.",
            "댓글 스레드를 해결하고 접을 수 있으며, 이슈 live banner가 대기 중인 에이전트 작업을 보여줍니다.",
            "실패하거나 취소된 작업을 실행 로그에서 한 번에 다시 실행할 수 있습니다.",
          ],
          improvements: [
            "이슈 타임라인 렌더링, 대용량 paste 처리, 오토파일럿 오프라인 dispatch 방지, 인박스 자동 보관, Hermes 요청 전달이 개선되었습니다.",
          ],
          fixes: [
            "잔액 부족 run 상태, 이미지 문제 복구, Pi 모델 목록 파싱, Priority 색상, 긴 에이전트 메시지, 데스크톱 링크 복사 등을 수정했습니다.",
          ],
        },
        {
          version: "0.2.28",
          date: "2026-05-08",
          title: "데몬 디스크 사용량 CLI와 타임라인 개선",
          changes: [],
          features: [
            "`multica daemon disk-usage`가 작업별, 워크스페이스별 디스크 사용량을 보여줍니다.",
            "에이전트 설정의 스킬 picker에 검색 상자가 추가되고 데몬 GC 범위가 채팅, 오토파일럿, quick-create 작업까지 확장되었습니다.",
            "이슈 상세 breadcrumb에 빠른 참조용 식별자가 표시됩니다.",
          ],
          improvements: [
            "타임라인 페이지 크기, 오래된/새로운 항목 보기, task_usage daily rollup, 데몬 health check, 런타임 통계가 개선되었습니다.",
          ],
          fixes: [
            "Linux 데몬 재시작, CLI short ID 라우팅, Windows 입력 파일 플래그, Electron 아이콘, orphaned reply, 타임라인 페이지네이션 예산을 수정했습니다.",
          ],
        },
        {
          version: "0.2.27",
          date: "2026-05-07",
          title: "더 매끄러운 채팅과 GitHub 스킬 가져오기",
          changes: [],
          features: [
            "GitHub 링크에서 재사용 가능한 스킬을 바로 가져올 수 있습니다.",
          ],
          improvements: [
            "채팅과 인박스, 이슈 작업 액션, 오토파일럿 반복 실패 감지가 더 매끄러워졌습니다.",
          ],
          fixes: [
            "중국어 입력, 데스크톱 업데이트, 긴 이슈 타임라인, live status 업데이트 안정성을 개선했습니다.",
          ],
        },
        {
          version: "0.2.26",
          date: "2026-05-06",
          title: "전체 i18n 적용과 시스템 알림 토글",
          changes: [],
          features: [
            "웹 앱이 간체 중국어로 완전히 번역되고 사용자별 로케일을 지원합니다.",
            "설정에 시스템 알림 토글, 채팅 세션 삭제, 인박스의 히스토리 패널, Redis 기반 런타임 liveness가 추가되었습니다.",
            "데스크톱은 런타임 셀프 호스트 설정을 로드하고 CLI는 명확한 대상 지정 플래그를 제공합니다.",
          ],
          improvements: [
            "설정 탭 이름과 URL 반영, 긴 이슈 타임라인, 런타임 poll/heartbeat 분리, Redis 기반 CLI 업데이트 요청, 사용량 쿼리 범위가 개선되었습니다.",
          ],
          fixes: [
            "서버 측 작업 삭제 시 데몬 취소, Codex auth refresh, ACP session resume, OpenCode skills 경로, 404 처리, sidebar pin, S3 URL, Windows installer 등을 수정했습니다.",
          ],
        },
        {
          version: "0.2.24",
          date: "2026-05-03",
          title: "Repo checkout --ref와 Hermes 재생 수정",
          changes: [],
          features: [
            "`multica repo checkout --ref`가 브랜치, 태그, 특정 커밋을 대상으로 저장소를 가져올 수 있습니다.",
            "`multica agent avatar`가 CLI에서 에이전트 아바타를 직접 업로드합니다.",
            "인박스 Done 작업에 보관 버튼이 추가되고 중복 mark-as-done hover 버튼은 제거되었습니다.",
          ],
          improvements: [
            "긴 타임라인 이슈 열기, multi-replica 모델 picker, 데몬 empty-claim cache TTL이 개선되었습니다.",
          ],
          fixes: [
            "새 에이전트 즉시 표시, Hermes 이전 답변 재생, Codex GPT-5.5 모델 표시, `multica login --token`, CLI 업데이트 상태, session resume, Kanban 설정, 오토파일럿 반응형 등을 수정했습니다.",
          ],
        },
        {
          version: "0.2.21",
          date: "2026-04-30",
          title: "Quick Capture 개편과 Mermaid 다이어그램",
          changes: [],
          features: [
            "기존 새 이슈 대화상자가 Quick Capture로 바뀌어 연속 생성, 파일 업로드, 붙여넣은 URL 자동 보강을 지원합니다.",
            "Mermaid 다이어그램이 Markdown 안에서 렌더링되고 복잡한 그래프는 전체 화면 lightbox로 볼 수 있습니다.",
            "프로젝트별 저장소 바인딩과 권한 인식 UI가 추가되었습니다.",
          ],
          improvements: [
            "데몬 claim polling의 Redis fast-path와 Multica Agent 커밋의 Co-authored-by trailer, 데스크톱 reload 차단이 개선되었습니다.",
          ],
          fixes: [
            "Quick Create 요구사항 생성, 인박스 댓글 이동과 자동 보관, 작업 재실행 session, 초대 후 워크스페이스 이동을 수정했습니다.",
          ],
        },
        {
          version: "0.2.20",
          date: "2026-04-29",
          title: "에이전트로 이슈 만들기와 Presence v3",
          changes: [],
          features: [
            "`c`를 눌러 한 줄을 작성하고 에이전트를 선택하면 에이전트가 비동기로 이슈를 만들고 결과를 인박스에 남깁니다.",
            "Agent Presence v3가 availability와 last-task를 더 명확히 나누고 실행 로그를 이슈 패널에 표시합니다.",
            "데몬과 서버 heartbeat가 WebSocket으로 흐르며 task startup latency가 줄었습니다.",
          ],
          improvements: [
            "PAT/daemon token 캐시, agent CLI args env var, 수동/에이전트 이슈 생성 대화상자 공유가 개선되었습니다.",
          ],
          fixes: [
            "에이전트 이슈 생성 queue 정체와 중복 생성, 줄바꿈 렌더링, agent-authored mention loop, Windows Cursor multi-line prompt를 수정했습니다.",
          ],
        },
        {
          version: "0.2.19",
          date: "2026-04-28",
          title: "Kiro CLI 런타임과 데스크톱 알림",
          changes: [],
          features: [
            "Kiro CLI가 로컬 에이전트 런타임 옵션으로 추가되었습니다.",
            "macOS dock badge와 native notification이 추가되어 읽지 않은 이슈로 바로 이동할 수 있습니다.",
            "이슈 목록이 라벨 필터를 지원하고 데몬은 WebSocket으로 task wakeup을 받습니다.",
          ],
          improvements: [
            "리스트/보드 상태 그룹 헤더, Markdown 링크 보존, 라벨 optimistic attach, mention picker 검색이 개선되었습니다.",
          ],
          fixes: [
            "댓글 삭제 시 에이전트 작업 취소, stalled Codex timeout, Windows 데몬 종료, 에이전트 간 mention loop를 수정했습니다.",
          ],
        },
        {
          version: "0.2.18",
          date: "2026-04-27",
          title: "이슈 라벨과 Labs 탭",
          changes: [],
          features: [
            "이슈 라벨로 list, board, detail view에서 색상 분류와 필터링을 할 수 있습니다.",
            "실험 토글을 위한 Labs 설정 탭과 읽지 않은 워크스페이스 초대 표시 dot이 추가되었습니다.",
          ],
          improvements: [
            "프로젝트 picker 아이콘, detail page sidebar highlight, self-host signup gating env var 처리가 개선되었습니다.",
          ],
          fixes: [
            "에이전트 댓글 줄바꿈, Fedora의 Desktop RPM 충돌, Windows 에이전트 multi-line prompt 처리를 수정했습니다.",
          ],
        },
        {
          version: "0.2.17",
          date: "2026-04-26",
          title: "사용자 지정 에이전트 환경 변수와 더 나은 실패 메시지",
          changes: [],
          features: [
            "`multica agent create/update --custom-env KEY=VALUE`가 에이전트 실행에 사용자 지정 환경 변수를 주입합니다.",
            "에이전트 실패 메시지에 런타임 CLI stderr tail이 포함되어 디버깅이 쉬워졌습니다.",
            "CLI 업데이트 다운로드 timeout을 설정할 수 있습니다.",
          ],
          improvements: [
            "데몬 cancelled 상태 보고와 agent status reconciliation, server heartbeat 분리와 slow-log가 개선되었습니다.",
          ],
          fixes: [
            "이슈 create/update의 assignee_id 검증, DeleteIssue ID 해석, Pi skills 경로, Windows console popup을 수정했습니다.",
          ],
        },
        {
          version: "0.2.16",
          date: "2026-04-25",
          title: "Chat V2와 이슈 우클릭 메뉴",
          changes: [],
          features: [
            "Chat V2, 이슈 우클릭 메뉴, 앱 내 피드백 흐름이 추가되었습니다.",
          ],
          improvements: [
            "채팅 사용성, 이슈 액션 접근성, 피드백 수집 흐름이 개선되었습니다.",
          ],
          fixes: [
            "채팅과 이슈 주변의 안정성 문제를 수정했습니다.",
          ],
        },
        {
          version: "0.2.15",
          date: "2026-04-24",
          title: "로컬 스킬, LaTeX, Focus Mode",
          changes: [],
          features: [
            "로컬 스킬, LaTeX 렌더링, Focus Mode, orphan task recovery가 추가되었습니다.",
          ],
          improvements: [
            "에이전트 작업 환경과 집중 작업 흐름이 개선되었습니다.",
          ],
          fixes: [
            "고아 작업 복구와 에디터 주변 안정성 문제를 수정했습니다.",
          ],
        },
        {
          version: "0.2.11",
          date: "2026-04-20",
          title: "크로스 플랫폼 데스크톱 패키징",
          changes: [],
          features: [
            "데스크톱 앱의 크로스 플랫폼 패키징, CLI self-update, 보드 페이지네이션이 추가되었습니다.",
          ],
          fixes: [
            "데스크톱 배포와 보드 로딩 안정성 문제를 수정했습니다.",
          ],
        },
        {
          version: "0.2.8",
          date: "2026-04-17",
          title: "에이전트별 모델과 Kimi 런타임",
          changes: [],
          features: [
            "에이전트별 모델 설정, Kimi 런타임, 셀프 호스트 인증 개선이 추가되었습니다.",
          ],
          fixes: [
            "모델 선택과 인증 흐름의 안정성 문제를 수정했습니다.",
          ],
        },
        {
          version: "0.2.7",
          date: "2026-04-16",
          title: "에디터 하위 이슈와 MCP",
          changes: [],
          features: [
            "에디터 선택 영역에서 하위 이슈를 만들고, 셀프 호스트 gating과 MCP 관련 기능을 사용할 수 있습니다.",
          ],
          fixes: [
            "하위 이슈 생성과 셀프 호스트 설정 주변 문제를 수정했습니다.",
          ],
        },
        {
          version: "0.2.5",
          date: "2026-04-14",
          title: "CLI 오토파일럿, Cmd+K, 데몬 identity",
          changes: [],
          features: [
            "CLI 오토파일럿 명령, Cmd+K 검색/명령 흐름, 데몬 identity 개선이 추가되었습니다.",
          ],
          fixes: [
            "명령 실행과 데몬 식별 주변 안정성 문제를 수정했습니다.",
          ],
        },
        {
          version: "0.2.1",
          date: "2026-04-10",
          title: "새 에이전트 런타임",
          changes: [],
          features: [
            "새 에이전트 런타임을 추가해 더 다양한 실행 환경을 지원합니다.",
          ],
          fixes: [
            "런타임 연결과 실행 안정성을 개선했습니다.",
          ],
        },
        {
          version: "0.2.0",
          date: "2026-04-09",
          title: "데스크톱 앱, 오토파일럿, 초대",
          changes: [],
          features: [
            "데스크톱 앱, 오토파일럿, 워크스페이스 초대 흐름이 추가되었습니다.",
          ],
          improvements: [
            "초기 제품 흐름과 런타임 연결 경험이 정리되었습니다.",
          ],
          fixes: [
            "데스크톱, 오토파일럿, 초대 기능의 초기 안정성 문제를 수정했습니다.",
          ],
        },
        {
          version: "0.1.33",
          date: "2026-04-07",
          title: "Gemini CLI와 에이전트 환경 변수",
          changes: [],
          features: [
            "Gemini CLI 지원과 에이전트 환경 변수 설정이 추가되었습니다.",
          ],
          improvements: [
            "에이전트 실행 설정 흐름이 더 유연해졌습니다.",
          ],
          fixes: [
            "CLI와 환경 변수 처리 주변 문제를 수정했습니다.",
          ],
        },
        {
          version: "0.1.28",
          date: "2026-04-02",
          title: "Windows 지원, 인증, 온보딩",
          changes: [],
          features: [
            "Windows 지원, 인증 흐름, 온보딩 경험이 추가되었습니다.",
          ],
          fixes: [
            "초기 Windows 실행과 로그인 안정성 문제를 수정했습니다.",
          ],
        },
        {
          version: "0.1.27",
          date: "2026-04-01",
          title: "원클릭 설정과 셀프 호스팅",
          changes: [],
          features: [
            "원클릭 설정, 셀프 호스팅 안내, 안정성 개선이 추가되었습니다.",
          ],
          improvements: [
            "초기 설치와 운영 경험이 더 단순해졌습니다.",
          ],
          fixes: [
            "설정과 배포 과정의 안정성 문제를 수정했습니다.",
          ],
        },
        {
          version: "0.1.24",
          date: "2026-03-29",
          title: "보안과 알림",
          changes: [],
          features: [
            "보안 기능과 알림 경험이 추가되었습니다.",
          ],
          improvements: [
            "팀 사용에 필요한 운영 안전성이 개선되었습니다.",
          ],
          fixes: [
            "알림과 접근 제어 주변 문제를 수정했습니다.",
          ],
        },
        {
          version: "0.1.23",
          date: "2026-03-28",
          title: "고정, Cmd+K, 프로젝트",
          changes: [],
          features: [
            "사이드바 고정, Cmd+K, 프로젝트 기능이 추가되었습니다.",
          ],
          fixes: [
            "프로젝트와 탐색 흐름의 초기 문제를 수정했습니다.",
          ],
        },
        {
          version: "0.1.22",
          date: "2026-03-27",
          title: "셀프 호스팅, ACP, 문서",
          changes: [],
          features: [
            "셀프 호스팅, ACP, 문서 관련 기능이 추가되었습니다.",
          ],
          improvements: [
            "설치와 운영 문서가 개선되었습니다.",
          ],
          fixes: [
            "셀프 호스팅과 문서 링크 주변 문제를 수정했습니다.",
          ],
        },
        {
          version: "0.1.21",
          date: "2026-03-26",
          title: "프로젝트, 검색, 모노레포",
          changes: [
            "프로젝트, 검색, 모노레포 지원을 추가했습니다.",
          ],
        },
        {
          version: "0.1.20",
          date: "2026-03-25",
          title: "하위 이슈, TanStack Query, 사용량 추적",
          changes: [
            "하위 이슈, TanStack Query 기반 데이터 흐름, 사용량 추적을 추가했습니다.",
          ],
        },
        {
          version: "0.1.18",
          date: "2026-03-23",
          title: "OAuth, OpenClaw, 이슈 로딩",
          changes: [
            "OAuth, OpenClaw 런타임, 이슈 로딩 개선을 추가했습니다.",
          ],
        },
        {
          version: "0.1.17",
          date: "2026-03-22",
          title: "댓글 페이지네이션과 CLI 정리",
          changes: [
            "댓글 페이지네이션과 CLI 사용성을 개선했습니다.",
          ],
        },
        {
          version: "0.1.15",
          date: "2026-03-20",
          title: "에디터 개편과 에이전트 생명주기",
          changes: [
            "에디터를 개편하고 에이전트 생명주기 관리를 개선했습니다.",
          ],
        },
        {
          version: "0.1.14",
          date: "2026-03-19",
          title: "멘션과 권한",
          changes: [
            "멘션과 권한 처리 흐름을 추가했습니다.",
          ],
        },
        {
          version: "0.1.13",
          date: "2026-03-18",
          title: "내 이슈와 i18n",
          changes: [
            "내 이슈 화면과 국제화 기반을 추가했습니다.",
          ],
        },
        {
          version: "0.1.3",
          date: "2026-03-08",
          title: "에이전트 지능",
          changes: [
            "에이전트 지능과 작업 처리 기반을 추가했습니다.",
          ],
        },
        {
          version: "0.1.2",
          date: "2026-03-07",
          title: "협업",
          changes: [
            "팀 협업을 위한 기본 흐름을 추가했습니다.",
          ],
        },
        {
          version: "0.1.1",
          date: "2026-03-06",
          title: "핵심 플랫폼",
          changes: [
            "Multica 핵심 플랫폼 기능을 추가했습니다.",
          ],
        },
        {
          version: "0.1.0",
          date: "2026-03-05",
          title: "기반 구축",
          changes: [
            "Multica의 초기 기반을 공개했습니다.",
          ],
        },
      ],
    },
    about: {
      title: "Multica 소개",
      nameLine: {
        prefix: "Multica — ",
        mul: "Mul",
        tiplexed: "tiplexed ",
        i: "I",
        nformationAnd: "nformation and ",
        c: "C",
        omputing: "omputing ",
        a: "A",
        gent: "gent.",
      },
      paragraphs: [
        "Multica라는 이름은 1960년대의 선구적인 운영체제 Multics에서 따왔습니다. Multics는 여러 사용자가 하나의 컴퓨터를 공유하면서도 각자 자기 컴퓨터를 쓰는 것처럼 느끼게 해 주는 시분할이라는 개념을 처음 널리 퍼뜨렸습니다. Unix는 Multics를 의도적으로 단순화하며 태어났습니다. 한 사용자, 한 작업, 하나의 우아한 철학에 집중한 결과였습니다.",
        "지금 비슷한 전환점이 다시 오고 있다고 봅니다. 지난 수십 년 동안 소프트웨어 팀은 사실상 단일 스레드로 일해 왔습니다. 엔지니어 한 명이 한 작업을 맡고, 한 번에 하나의 맥락만 다루는 식이었습니다. AI 에이전트는 이 공식을 바꿉니다. Multica는 시분할의 발상을 다시 꺼내 오되, 이번에는 시스템을 함께 쓰는 \"사용자\"가 사람과 자율 에이전트 양쪽을 의미하는 시대에 맞게 다시 풀어냅니다.",
        "Multica에서 에이전트는 정식 팀원입니다. 사람 동료와 똑같이 이슈를 할당받고, 진행 상황을 보고하고, 막힌 부분을 알리고, 코드를 배포합니다. 담당자 선택, 활동 타임라인, 작업 생명주기, 런타임 인프라는 모두 이 전제를 중심으로 처음부터 설계되었습니다.",
        "Multics가 그랬듯, 핵심은 multiplexing입니다. 작은 팀이라고 작게 움직일 필요는 없습니다. 올바른 시스템이 있다면 엔지니어 두 명과 에이전트 한 무리가 스무 명짜리 팀처럼 움직일 수 있습니다.",
        "Multica는 완전한 오픈소스이며 셀프 호스팅할 수 있습니다. 데이터는 여러분의 인프라 안에 그대로 남습니다. 모든 코드를 들여다보고, API를 확장하고, 원하는 LLM 제공자를 연결하고, 커뮤니티에 기여할 수 있습니다.",
      ],
      cta: "GitHub에서 보기",
    },
    download: {
      hero: {
        macArm64: {
          title: "macOS용 Multica",
          sub: "Apple Silicon · 데몬 포함, 별도 설정 없음",
          primary: "다운로드(.dmg)",
          altZip: "또는 .zip 다운로드",
        },
        macIntel: {
          title: "macOS용 Multica",
          sub: "Apple Silicon이 필요합니다. Intel Mac은 아직 지원하지 않습니다.",
          disabledCta: "Apple Silicon 필요",
          intelHint:
            "Intel Mac을 사용 중인가요? 아래 CLI를 사용하세요. 같은 데몬이 실행됩니다.",
        },
        winX64: {
          title: "Windows용 Multica",
          sub: "데몬 포함, 별도 설정 없음",
          primary: "다운로드(.exe)",
        },
        winArm64: {
          title: "Windows용 Multica",
          sub: "ARM · 데몬 포함, 별도 설정 없음",
          primary: "다운로드(.exe)",
        },
        linux: {
          title: "Linux용 Multica",
          sub: "데몬 포함, 별도 설정 없음",
          primary: "AppImage 다운로드",
          altFormats: "또는 .deb / .rpm",
        },
        unknown: {
          title: "플랫폼 선택",
          sub: "모든 설치 파일은 아래에 정리되어 있습니다.",
        },
        safariMacHint: "Intel Mac을 사용 중인가요? 아래 CLI를 사용하세요.",
        archFallbackHint: "아키텍처가 맞지 않나요? 아래에서 모든 형식을 확인하세요.",
      },
      allPlatforms: {
        title: "모든 플랫폼",
        macLabel: "macOS · Apple Silicon",
        winX64Label: "Windows · x64",
        winArm64Label: "Windows · ARM64",
        linuxX64Label: "Linux · x64",
        linuxArm64Label: "Linux · ARM64",
        formatDmg: ".dmg",
        formatZip: ".zip",
        formatExe: ".exe",
        formatAppImage: ".AppImage",
        formatDeb: ".deb",
        formatRpm: ".rpm",
        intelNote:
          "Apple Silicon만 지원합니다. 이번 릴리스에서는 Intel Mac을 지원하지 않습니다.",
        unavailable: "사용할 수 없음",
      },
      cli: {
        title: "CLI가 더 편하신가요?",
        sub: "서버, 원격 개발 환경, headless 환경에 적합합니다. 데스크톱과 동일한 데몬을 터미널에서 바로 설치할 수 있습니다.",
        installLabel: "설치",
        startLabel: "데몬 시작",
        sshNote: "이미 서버에 접속해 있나요? 같은 명령을 SSH에서도 그대로 사용할 수 있습니다.",
        copyLabel: "복사",
        copiedLabel: "복사했습니다",
      },
      cloud: {
        title: "클라우드 런타임 (대기자 명단)",
        sub: "Multica가 런타임을 직접 호스팅해 드립니다. 아직 정식 출시 전입니다. 이메일을 남겨 주시면 준비되는 대로 알려드릴게요.",
      },
      footer: {
        releaseNotes: "{version}의 새로운 내용",
        allReleases: "모든 릴리스 보기",
        currentVersion: "현재 버전: {version}",
        versionUnavailable: "버전을 확인할 수 없습니다. GitHub를 확인하세요.",
      },
    },
    contactSales: {
      pageTitle: "영업팀 문의",
      pageDescription:
        "회사에 사람과 에이전트가 함께 일하는 워크플로를 도입하는 방법을 Multica 팀과 함께 이야기해 보세요.",
      eyebrow: "영업팀 문의",
      title: "어떤 도움이 필요하신지 알려 주세요",
      subtitle: "가장 알맞은 방안을 미리 준비해 드릴 수 있도록, 몇 가지만 적어 주세요.",
      notice: {
        badge: "시스템은 비즈니스 이메일 도메인만 인식합니다.",
        body: "개인 이메일 주소(예: @gmail.com, @outlook.com)로 보내신 요청은 시스템에서 인식되지 않아 처리되지 않습니다.",
      },
      fields: {
        firstName: "이름",
        lastName: "성",
        businessEmail: "비즈니스 이메일",
        businessEmailHint:
          "회사 이메일이 필요합니다. 답신을 드릴 수 있도록 유효한 회사 도메인을 사용해 주세요.",
        companyName: "회사명",
        companySize: "회사 규모",
        countryRegion: "국가 / 지역",
        useCase: "Multica를 어떻게 사용하거나 어디에 활용하실 계획인가요?",
        goals: "목표 또는 현재 겪고 있는 과제",
        goalsHint:
          "Multica로 이루고 싶은 일이나 지금 겪고 있는 문제를 알려 주세요. 자세히 적어 주실수록 더 알맞게 도와드릴 수 있습니다.",
        selectPlaceholder: "선택하세요",
        submit: "제출",
        submitting: "제출 중...",
      },
      companySizes: [
        { value: "1-10", label: "직원 1-10명" },
        { value: "11-50", label: "직원 11-50명" },
        { value: "51-200", label: "직원 51-200명" },
        { value: "201-500", label: "직원 201-500명" },
        { value: "501-1000", label: "직원 501-1,000명" },
        { value: "1000+", label: "직원 1,000명 이상" },
      ],
      useCases: [
        { value: "evaluate", label: "팀 도입을 검토 중" },
        { value: "adopt_team", label: "팀 또는 회사에 Multica 도입" },
        { value: "self_host", label: "자체 인프라에 셀프 호스팅" },
        { value: "integrate", label: "기존 도구와 Multica 연동" },
        { value: "partner", label: "파트너십 또는 리셀러 문의" },
        { value: "other", label: "기타" },
      ],
      countries: [
        "미국",
        "캐나다",
        "영국",
        "독일",
        "프랑스",
        "네덜란드",
        "스웨덴",
        "스위스",
        "스페인",
        "이탈리아",
        "아일랜드",
        "노르웨이",
        "덴마크",
        "핀란드",
        "벨기에",
        "포르투갈",
        "호주",
        "뉴질랜드",
        "일본",
        "대한민국",
        "싱가포르",
        "홍콩 특별행정구",
        "대만",
        "중국 본토",
        "인도",
        "인도네시아",
        "태국",
        "베트남",
        "필리핀",
        "말레이시아",
        "아랍에미리트",
        "사우디아라비아",
        "이스라엘",
        "튀르키예",
        "남아프리카공화국",
        "브라질",
        "멕시코",
        "아르헨티나",
        "칠레",
        "기타",
      ],
      consent: {
        intro:
          "Multica, Inc.는 여러분의 개인정보를 소중히 다룹니다. 제공해 주신 개인정보는 계정 관리와 요청하신 제품·서비스 제공에만 사용합니다. 가끔씩 제품 업데이트, 활용 팁, 도움이 될 만한 인사이트도 함께 전해 드리고 싶습니다. 소식을 받고 싶으시다면 아래에서 선택해 주세요.",
        outreach:
          "서비스 업데이트, 지원 문의, 비즈니스 관련 후속 연락 등 Multica, Inc.로부터 개별 연락을 받겠습니다.",
        updates:
          "Multica의 제품 업데이트, 인사이트, 이벤트 초대 소식을 받겠습니다.",
        unsubscribe:
          "언제든 수신을 거부할 수 있습니다. 개인정보와 데이터 권리를 어떻게 다루는지는 다음 문서에서 자세히 확인하실 수 있습니다:",
        submitConsent:
          "\"제출\"을 클릭하시면 요청하신 콘텐츠를 보내 드리기 위해 Multica, Inc.가 정보를 저장하고 처리하는 것에 동의하게 됩니다.",
        privacyLinkLabel: "개인정보 처리방침.",
        privacyLinkHref: "/about",
      },
      success: {
        title: "감사합니다. 요청을 잘 받았습니다.",
        message:
          "Multica 팀원이 영업일 기준 3일 이내에 답변드릴 예정입니다. 그동안 문서를 둘러보시거나 GitHub에서 스타를 눌러 주세요.",
        cta: "홈으로 돌아가기",
      },
      errors: {
        generic: "문제가 발생했습니다. 잠시 후 다시 시도해 주세요.",
        rateLimit:
          "최근 이 주소에서 여러 건의 문의가 접수되었습니다. 잠시 후 다시 시도해 주세요.",
        freeEmail:
          "비즈니스 이메일 주소를 사용해 주세요. 무료 이메일 서비스(gmail, outlook 등)는 사용하실 수 없습니다.",
        invalidEmail: "올바른 이메일 주소 형식이 아닌 것 같습니다.",
      },
    },
  };
}
